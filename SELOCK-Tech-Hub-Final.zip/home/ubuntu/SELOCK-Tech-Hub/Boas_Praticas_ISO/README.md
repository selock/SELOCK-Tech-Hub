# Boas Práticas ISO e NIST Selock

Este diretório reúne documentação e checklists relacionados a padrões internacionais de segurança da informação, como ISO/IEC 27001, ISO/IEC 27701 e NIST CSF, demonstrando o compromisso da Selock com a governança e compliance.

## Conteúdo

- **ISO/IEC 27001**: Checklists e procedimentos para a implementação e manutenção de um Sistema de Gestão de Segurança da Informação (SGSI).
- **ISO/IEC 27701**: Diretrizes para a gestão da privacidade da informação, em conformidade com a LGPD.
- **NIST CSF**: Framework de Cibersegurança do NIST, com orientações para identificar, proteger, detectar, responder e recuperar.
