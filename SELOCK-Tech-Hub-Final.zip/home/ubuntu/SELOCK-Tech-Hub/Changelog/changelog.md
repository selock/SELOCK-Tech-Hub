# Changelog - SELOCK-Tech-Hub

## v1.0.0 - 10/01/2026
- Estrutura inicial do repositório
- README.md completo com descrição institucional
- Pastas de Documentos, Guias, Boas Práticas, Tutoriais, LGPD e Exemplos de Serviços
- Licença MIT aplicada
