# LGPD Compliance Selock

Este diretório contém a documentação e os procedimentos da Selock relacionados à conformidade com a Lei Geral de Proteção de Dados (LGPD), demonstrando nosso compromisso com a privacidade e proteção de dados pessoais.

## Conteúdo

- **Procedimentos de Tratamento de Dados**: Documentos que descrevem como a Selock coleta, armazena, processa e descarta dados pessoais.
- **Fluxos de Opt-In e Opt-Out**: Detalhes sobre como os titulares de dados podem consentir ou revogar o consentimento para o tratamento de seus dados.
- **Canal de Exercício de Direitos**: Informações sobre como os titulares de dados podem exercer seus direitos (acesso, correção, exclusão, etc.).
