# port_scanner.py

Um script Python simples para verificar se portas específicas estão abertas em um IP alvo.

## Uso

```bash
python3 port_scanner.py <IP_ALVO> <PORTAS_EX: 80,443,22>
```

### Exemplos

Para escanear as portas 80 e 443 no IP 192.168.1.1:

```bash
python3 port_scanner.py 192.168.1.1 80,443
```

## Pré-requisitos

- Python 3.x

## Como Funciona

O script tenta estabelecer uma conexão TCP com as portas especificadas no IP alvo. Se a conexão for bem-sucedida, a porta é considerada aberta. Caso contrário, é considerada fechada ou inacessível.
