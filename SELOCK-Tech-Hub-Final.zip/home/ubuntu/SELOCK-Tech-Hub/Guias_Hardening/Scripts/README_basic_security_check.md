# basic_security_check.sh

Um script shell simples para realizar verificações básicas de segurança em sistemas Linux, como status do firewall, configurações de SSH e usuários sem senha.

## Uso

```bash
bash basic_security_check.sh
```

### Exemplos

```bash
bash basic_security_check.sh
```

## Pré-requisitos

- Shell Bash
- `ufw` (para verificação de firewall no Ubuntu/Debian)
- Permissões de `sudo` para algumas verificações

## Como Funciona

O script executa uma série de comandos para:
- Verificar se o UFW (Uncomplicated Firewall) está ativo e exibir suas regras.
- Analisar o arquivo `/etc/ssh/sshd_config` para identificar se o login de root e a autenticação por senha estão habilitados via SSH.
- Verificar o arquivo `/etc/shadow` para identificar usuários sem senha.

**Importante**: Este script fornece uma verificação básica e não substitui uma auditoria de segurança completa. Ele deve ser usado como um ponto de partida para identificar configurações potencialmente inseguras.
