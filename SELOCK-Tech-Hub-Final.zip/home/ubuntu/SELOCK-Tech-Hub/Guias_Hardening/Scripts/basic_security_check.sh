#!/bin/bash

# Script para verificar configurações básicas de segurança

echo "Iniciando verificação básica de segurança..."

# 1. Verificar se o firewall está ativo (UFW no Ubuntu/Debian)
if command -v ufw &> /dev/null
then
    echo "\n--- Verificação de Firewall (UFW) ---"
    sudo ufw status | grep -q "Status: active"
    if [ $? -eq 0 ]; then
        echo "UFW está ativo."
    else
        echo "UFW está inativo. Considere ativá-lo."
    fi
    sudo ufw status verbose
else
    echo "UFW não encontrado. Verifique se outro firewall está em uso."
fi

# 2. Verificar se o SSH permite login de root
echo "\n--- Verificação de Login de Root via SSH ---"
if grep -q "^PermitRootLogin yes" /etc/ssh/sshd_config; then
    echo "AVISO: Login de root via SSH está permitido. Considere desabilitar."
else
    echo "Login de root via SSH está desabilitado (OK)."
fi

# 3. Verificar se a autenticação por senha SSH está habilitada
echo "\n--- Verificação de Autenticação por Senha SSH ---"
if grep -q "^PasswordAuthentication yes" /etc/ssh/sshd_config; then
    echo "AVISO: Autenticação por senha SSH está habilitada. Considere usar chaves SSH."
else
    echo "Autenticação por senha SSH está desabilitada (OK)."
fi

# 4. Verificar se há usuários sem senha (apenas para sistemas Linux)
echo "\n--- Verificação de Usuários sem Senha ---"
if [ -f /etc/shadow ]; then
    NO_PASSWORD_USERS=$(sudo awk -F: '($2 == "" || $2 == "!") {print $1}' /etc/shadow)
    if [ -n "$NO_PASSWORD_USERS" ]; then
        echo "AVISO: Os seguintes usuários não possuem senha: $NO_PASSWORD_USERS"
    else
        echo "Nenhum usuário sem senha encontrado (OK)."
    fi
else
    echo "Arquivo /etc/shadow não encontrado. Não foi possível verificar usuários sem senha."
fi

echo "\nVerificação básica de segurança concluída."
