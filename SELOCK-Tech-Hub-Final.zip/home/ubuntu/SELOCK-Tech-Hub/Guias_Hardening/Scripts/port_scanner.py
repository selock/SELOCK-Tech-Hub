#!/usr/bin/env python3

import socket
import sys

def scan_port(ip, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip, port))
        if result == 0:
            return True
        else:
            return False
    except socket.error as e:
        print(f"Erro de conexão: {e}")
        return False
    finally:
        sock.close()

def main():
    if len(sys.argv) != 3:
        print("Uso: python3 port_scanner.py <IP_ALVO> <PORTAS_EX: 80,443,22>")
        sys.exit(1)

    target_ip = sys.argv[1]
    ports_str = sys.argv[2]
    ports = [int(p.strip()) for p in ports_str.split(',')]

    print(f"Escaneando IP: {target_ip} para portas: {ports_str}\n")

    for port in ports:
        if scan_port(target_ip, port):
            print(f"Porta {port} está ABERTA")
        else:
            print(f"Porta {port} está FECHADA")

if __name__ == "__main__":
    main()
