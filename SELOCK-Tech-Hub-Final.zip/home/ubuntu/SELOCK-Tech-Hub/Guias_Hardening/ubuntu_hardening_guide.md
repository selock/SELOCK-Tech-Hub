# Guia de Hardening para Ubuntu Server

Este guia fornece passos essenciais para endurecer (harden) uma instalação padrão do Ubuntu Server, aumentando sua segurança contra ataques comuns.

## 1. Atualizar o Sistema

É crucial manter o sistema operacional e todos os pacotes atualizados para garantir que você tenha as últimas correções de segurança.

```bash
sudo apt update && sudo apt upgrade -y
sudo apt dist-upgrade -y
sudo apt autoremove -y
```

## 2. Configurar Firewall (UFW)

O Uncomplicated Firewall (UFW) é uma interface amigável para o `iptables` e é recomendado para gerenciar regras de firewall.

### Habilitar UFW

```bash
sudo ufw enable
sudo ufw status verbose
```

### Regras Básicas

-   **Negar tudo por padrão e permitir SSH**: Permite acesso SSH (porta 22) e nega todo o resto por padrão.

    ```bash
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw enable
    ```

-   **Permitir HTTP/HTTPS (se for um servidor web)**:

    ```bash
    sudo ufw allow http
    sudo ufw allow https
    ```

## 3. Proteger SSH

O SSH é um ponto de entrada comum. Protegê-lo é fundamental.

### Desabilitar Login de Root

Edite o arquivo de configuração do SSH:

```bash
sudo nano /etc/ssh/sshd_config
```

Altere a linha `PermitRootLogin` para `no`:

```
PermitRootLogin no
```

### Usar Autenticação por Chave SSH

Desabilite a autenticação por senha para maior segurança. Altere a linha `PasswordAuthentication` para `no`:

```
PasswordAuthentication no
```

### Mudar Porta Padrão (Opcional)

Alterar a porta padrão (22) pode reduzir ataques automatizados. Escolha uma porta alta e não utilizada (ex: 2222).

```
Port 2222
```

Após as alterações, reinicie o serviço SSH:

```bash
sudo systemctl restart ssh
```

**Importante**: Certifique-se de que você pode acessar o servidor pela nova porta (se alterada) e com a chave SSH antes de fechar a sessão atual.

## 4. Instalar Ferramentas de Segurança Adicionais

-   **Fail2Ban**: Protege contra ataques de força bruta, banindo IPs maliciosos.

    ```bash
    sudo apt install fail2ban -y
    sudo systemctl enable fail2ban
    sudo systemctl start fail2ban
    ```

-   **Lynis**: Ferramenta de auditoria de segurança para sistemas baseados em Unix.

    ```bash
    sudo apt install lynis -y
    sudo lynis audit system
    ```

## 5. Remover Pacotes Desnecessários

Minimize a superfície de ataque removendo serviços e pacotes que não são essenciais.

```bash
sudo apt purge apache2* samba* nfs-kernel-server* -y # Exemplo, remova o que não for usado
sudo apt autoremove -y
```

## 6. Configurar Auditoria de Logs (Auditd)

O `auditd` permite registrar eventos de segurança importantes no sistema.

```bash
sudo apt install auditd audispd-plugins -y
sudo systemctl enable auditd
sudo systemctl start auditd
```

Configure regras de auditoria conforme a necessidade da Selock.

## 7. Desabilitar IPv6 (se não for usado)

Se o IPv6 não for utilizado na sua infraestrutura, desabilitá-lo pode simplificar a configuração de segurança.

Edite o arquivo `/etc/sysctl.conf` e adicione as seguintes linhas:

```
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
```

Para aplicar as alterações:

```bash
sudo sysctl -p
```

## 8. Monitoramento e Manutenção

-   **Monitoramento de Logs**: Implemente uma solução de monitoramento centralizado de logs (SIEM) para analisar eventos de segurança.
-   **Backups Regulares**: Mantenha backups regulares e testados de todos os dados críticos.
-   **Revisões Periódicas**: Revise periodicamente as configurações de segurança e este guia para garantir que permaneçam eficazes.

---

**Autor**: Equipe de Segurança Selock
**Data**: 10 de janeiro de 2026
