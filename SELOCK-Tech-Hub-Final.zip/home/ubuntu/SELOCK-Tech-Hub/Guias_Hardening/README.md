# Guias de Hardening Selock

Este diretório contém guias detalhados, scripts e checklists para o hardening (endurecimento) de sistemas, serviços e dispositivos, visando fortalecer a postura de segurança da Selock.

## Conteúdo

- **Scripts**: Scripts de automação para hardening e auditoria.
- **Checklists**: Listas de verificação de boas práticas de segurança.
- **Guias Específicos**: Documentação detalhada para hardening de sistemas operacionais, serviços e dispositivos de rede.
