# Security Policy

Para relatar vulnerabilidades de segurança, entre em contato via e-mail:
**geral@selock.net**

Todos os relatos serão tratados com **confidencialidade e prioridade máxima**.
